package com.jionglin.rhythmguardian

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class BlockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var seconds by remember { mutableIntStateOf(10) }
                LaunchedEffect(Unit) {
                    while (seconds > 0) { delay(1_000); seconds-- }
                }
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.errorContainer) {
                    Column(
                        Modifier.padding(28.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("你打开的是视频号", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(16.dp))
                        Text("这不是休息，它会继续消耗你的注意力。\n本次尝试已记录并扣除 5 分。")
                        Spacer(Modifier.height(28.dp))
                        Button(onClick = { finish() }, enabled = seconds == 0) {
                            Text(if (seconds > 0) "停一下（${seconds}s）" else "回到该做的事")
                        }
                    }
                }
            }
        }
    }
}
