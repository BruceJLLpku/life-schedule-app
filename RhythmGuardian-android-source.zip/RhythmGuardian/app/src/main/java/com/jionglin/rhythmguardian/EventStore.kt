package com.jionglin.rhythmguardian

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class RhythmEvent(val time: Long, val type: String, val detail: String, val delta: Int)

class EventStore(private val appContext: Context) : SQLiteOpenHelper(appContext, "rhythm.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER NOT NULL, type TEXT NOT NULL, detail TEXT NOT NULL, delta INTEGER NOT NULL DEFAULT 0)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun add(type: String, detail: String, delta: Int = 0, time: Long = System.currentTimeMillis()) {
        writableDatabase.insert("events", null, ContentValues().apply {
            put("time", time); put("type", type); put("detail", detail); put("delta", delta)
        })
        if (delta != 0) AppPrefs(appContext).run { points += delta }
    }

    fun recent(limit: Int = 20): List<RhythmEvent> {
        val result = mutableListOf<RhythmEvent>()
        readableDatabase.rawQuery(
            "SELECT time,type,detail,delta FROM events ORDER BY time DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += RhythmEvent(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getInt(3))
            }
        }
        return result
    }

    fun hasEventSince(type: String, since: Long): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM events WHERE type=? AND time>=? LIMIT 1", arrayOf(type, since.toString())
    ).use { it.moveToFirst() }
}
