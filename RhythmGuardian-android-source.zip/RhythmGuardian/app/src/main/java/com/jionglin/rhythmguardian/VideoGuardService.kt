package com.jionglin.rhythmguardian

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class VideoGuardService : AccessibilityService() {
    private var lastBlockAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != UsageRepository.WECHAT_PACKAGE) return
        val sourceText = buildString {
            append(event.text.joinToString(" "))
            event.contentDescription?.let { append(" ").append(it) }
        }
        val clickedVideoChannel = event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            VIDEO_WORDS.any { sourceText.contains(it, ignoreCase = true) }
        val channelScreenVisible = event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED &&
            containsVideoChannelMarker(rootInActiveWindow)

        if ((clickedVideoChannel || channelScreenVisible) && shouldBlock()) blockNow()
    }

    override fun onInterrupt() = Unit

    private fun shouldBlock(): Boolean {
        val prefs = AppPrefs(this)
        val now = System.currentTimeMillis()
        if (prefs.rewardPassUntil > now) return false
        val morningEnd = prefs.lastWakeAt + prefs.morningBlockMinutes * 60_000L
        val morningBlocked = prefs.lastWakeAt > 0L && now < morningEnd
        val overDailyLimit = UsageRepository(this).weChatUsageTodayMillis() >= prefs.dailyLimitMinutes * 60_000L
        return morningBlocked || overDailyLimit
    }

    private fun blockNow() {
        val now = System.currentTimeMillis()
        if (now - lastBlockAt < 1_500L) return
        lastBlockAt = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        val prefs = AppPrefs(this)
        prefs.blockedAttemptsToday += 1
        EventStore(this).add("BLOCK", "拦截一次视频号，扣5分", -5)
        startActivity(Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        })
    }

    private fun containsVideoChannelMarker(root: AccessibilityNodeInfo?): Boolean {
        if (root == null) return false
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited++ < 250) {
            val node = queue.removeFirst()
            val text = "${node.text.orEmpty()} ${node.contentDescription.orEmpty()}"
            if (VIDEO_SCREEN_MARKERS.any { text.contains(it, ignoreCase = true) }) return true
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return false
    }

    companion object {
        private val VIDEO_WORDS = listOf("视频号", "Channels")
        // Markers intentionally require video-specific UI terms to avoid blocking chats.
        private val VIDEO_SCREEN_MARKERS = listOf("视频号", "原声", "私信作者", "轻触屏幕暂停")
    }
}
