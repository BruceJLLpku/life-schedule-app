package com.jionglin.rhythmguardian

import android.content.Context
import java.time.LocalTime

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("rhythm_guardian", Context.MODE_PRIVATE)

    var wakeHour: Int
        get() = prefs.getInt("wake_hour", 8)
        set(value) = prefs.edit().putInt("wake_hour", value.coerceIn(0, 23)).apply()
    var wakeMinute: Int
        get() = prefs.getInt("wake_minute", 0)
        set(value) = prefs.edit().putInt("wake_minute", value.coerceIn(0, 59)).apply()
    var bedtimeHour: Int
        get() = prefs.getInt("bed_hour", 0)
        set(value) = prefs.edit().putInt("bed_hour", value.coerceIn(0, 23)).apply()
    var dailyLimitMinutes: Int
        get() = prefs.getInt("daily_limit", 30)
        set(value) = prefs.edit().putInt("daily_limit", value.coerceIn(5, 240)).apply()
    var morningBlockMinutes: Int
        get() = prefs.getInt("morning_block", 90)
        set(value) = prefs.edit().putInt("morning_block", value.coerceIn(0, 240)).apply()
    var points: Int
        get() = prefs.getInt("points", 0)
        set(value) = prefs.edit().putInt("points", value).apply()
    var alarmEnabled: Boolean
        get() = prefs.getBoolean("alarm_enabled", true)
        set(value) = prefs.edit().putBoolean("alarm_enabled", value).apply()
    var lastWakeAt: Long
        get() = prefs.getLong("last_wake_at", 0L)
        set(value) = prefs.edit().putLong("last_wake_at", value).apply()
    var lastEstimatedBedtime: Long
        get() = prefs.getLong("estimated_bedtime", 0L)
        set(value) = prefs.edit().putLong("estimated_bedtime", value).apply()
    var blockedAttemptsToday: Int
        get() = prefs.getInt(dayKey("blocked"), 0)
        set(value) = prefs.edit().putInt(dayKey("blocked"), value).apply()
    var rewardedDay: String
        get() = prefs.getString("rewarded_day", "") ?: ""
        set(value) = prefs.edit().putString("rewarded_day", value).apply()
    var rewardPassUntil: Long
        get() = prefs.getLong("reward_pass_until", 0L)
        set(value) = prefs.edit().putLong("reward_pass_until", value).apply()

    fun wakeTime(): LocalTime = LocalTime.of(wakeHour, wakeMinute)
    fun bedtime(): LocalTime = LocalTime.of(bedtimeHour, 0)

    private fun dayKey(prefix: String): String = "$prefix-${java.time.LocalDate.now()}"
}
