package com.jionglin.rhythmguardian

import android.Manifest
import android.app.AlarmManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        AlarmScheduler.schedule(this)
        setContent { GuardianApp() }
    }

    override fun onResume() {
        super.onResume()
        AlarmScheduler.schedule(this)
    }

    @Composable
    private fun GuardianApp() {
        val prefs = remember { AppPrefs(this) }
        val usage = remember { UsageRepository(this) }
        val store = remember { EventStore(this) }
        var showSettings by remember { mutableStateOf(false) }
        var usageMillis by remember { mutableLongStateOf(0L) }
        var events by remember { mutableStateOf(store.recent()) }
        var points by remember { mutableIntStateOf(prefs.points) }
        var usageAccess by remember { mutableStateOf(usage.hasUsageAccess()) }
        var accessibility by remember { mutableStateOf(isGuardEnabled()) }

        LaunchedEffect(showSettings) {
            while (true) {
                usageMillis = usage.weChatUsageTodayMillis()
                events = store.recent()
                points = prefs.points
                usageAccess = usage.hasUsageAccess()
                accessibility = isGuardEnabled()
                delay(5_000)
            }
        }

        val colors = lightColorScheme(
            primary = Color(0xFF355E4B),
            secondary = Color(0xFF876A38),
            background = Color(0xFFF7F3E8),
            surface = Color(0xFFFFFBF2)
        )
        MaterialTheme(colorScheme = colors) {
            Surface(Modifier.fillMaxSize()) {
                if (showSettings) SettingsScreen(prefs) {
                    AlarmScheduler.schedule(this)
                    showSettings = false
                } else Dashboard(
                    prefs = prefs,
                    usageMillis = usageMillis,
                    events = events,
                    points = points,
                    usageAccess = usageAccess,
                    accessibility = accessibility,
                    onUsagePermission = { startActivity(UsageRepository.usageSettingsIntent) },
                    onAccessibilityPermission = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    onAlarmPermission = { openAlarmPermission() },
                    onRedeem = {
                        if (prefs.points >= 100) {
                            prefs.points -= 100
                            prefs.rewardPassUntil = System.currentTimeMillis() + 15 * 60_000L
                            store.add("REWARD", "兑换15分钟可控娱乐时间")
                            points = prefs.points
                            events = store.recent()
                        }
                    },
                    onSettings = { showSettings = true }
                )
            }
        }
    }

    @Composable
    private fun Dashboard(
        prefs: AppPrefs,
        usageMillis: Long,
        events: List<RhythmEvent>,
        points: Int,
        usageAccess: Boolean,
        accessibility: Boolean,
        onUsagePermission: () -> Unit,
        onAccessibilityPermission: () -> Unit,
        onAlarmPermission: () -> Unit,
        onRedeem: () -> Unit,
        onSettings: () -> Unit
    ) {
        val usedMinutes = (usageMillis / 60_000).toInt()
        val progress = (usedMinutes.toFloat() / prefs.dailyLimitMinutes).coerceIn(0f, 1f)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("今天由你接管", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("稳定比完美更重要") }
                TextButton(onClick = onSettings) { Text("设置") }
            }

            if (!usageAccess || !accessibility) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("还差必要权限", fontWeight = FontWeight.Bold)
                        if (!usageAccess) Button(onClick = onUsagePermission) { Text("允许读取使用时间") }
                        if (!accessibility) Button(onClick = onAccessibilityPermission) { Text("启用“视频号守卫”") }
                        if (Build.VERSION.SDK_INT >= 31) OutlinedButton(onClick = onAlarmPermission) { Text("允许准时闹钟") }
                    }
                }
            }

            Card {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("短视频预算", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("$usedMinutes / ${prefs.dailyLimitMinutes} 分钟", style = MaterialTheme.typography.headlineMedium)
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    Text("按你的使用习惯，当前以微信前台时间作为视频号的保守估计。", style = MaterialTheme.typography.bodySmall)
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("起床", formatTime(prefs.lastWakeAt), Modifier.weight(1f))
                StatCard("昨晚停用", formatTime(prefs.lastEstimatedBedtime), Modifier.weight(1f))
            }

            Card {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("积分与反馈", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("$points 分", style = MaterialTheme.typography.headlineMedium)
                    Text(feedbackText(prefs, usedMinutes))
                    Button(onClick = onRedeem, enabled = points >= 100 && prefs.rewardPassUntil < System.currentTimeMillis()) {
                        Text("100分兑换15分钟娱乐")
                    }
                    if (prefs.rewardPassUntil > System.currentTimeMillis()) Text("奖励时间正在使用，结束后自动恢复限制。")
                }
            }

            Text("今日轨迹", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (events.isEmpty()) Text("完成权限设置后，闹钟、起床和拦截记录会出现在这里。")
            events.take(10).forEach { event ->
                ListItem(
                    headlineContent = { Text(event.detail) },
                    supportingContent = { Text("${formatTime(event.time)} · ${event.type}") },
                    trailingContent = { if (event.delta != 0) Text(if (event.delta > 0) "+${event.delta}" else "${event.delta}") }
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    @Composable
    private fun StatCard(label: String, value: String, modifier: Modifier) {
        Card(modifier) { Column(Modifier.padding(16.dp)) { Text(label); Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) } }
    }

    @Composable
    private fun SettingsScreen(prefs: AppPrefs, onDone: () -> Unit) {
        var wakeHour by remember { mutableIntStateOf(prefs.wakeHour) }
        var limit by remember { mutableIntStateOf(prefs.dailyLimitMinutes) }
        var morning by remember { mutableIntStateOf(prefs.morningBlockMinutes) }
        var alarm by remember { mutableStateOf(prefs.alarmEnabled) }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("接管规则", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            StepSetting("每天起床", "%02d:00".format(wakeHour), { wakeHour = (wakeHour - 1).coerceAtLeast(5) }, { wakeHour = (wakeHour + 1).coerceAtMost(12) })
            StepSetting("每日微信/视频号额度", "$limit 分钟", { limit = (limit - 5).coerceAtLeast(5) }, { limit = (limit + 5).coerceAtMost(120) })
            StepSetting("起床后封锁视频号", "$morning 分钟", { morning = (morning - 15).coerceAtLeast(0) }, { morning = (morning + 15).coerceAtMost(240) })
            Row(verticalAlignment = Alignment.CenterVertically) { Switch(alarm, { alarm = it }); Spacer(Modifier.width(10.dp)); Text("启用每日闹钟") }
            Text("奖惩：确认起床 +20；守住晨间 +30；全天达标 +40；贪睡 -10；尝试打开受限视频号 -5；超过双倍额度 -20；100分可兑换15分钟娱乐。", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = {
                prefs.wakeHour = wakeHour
                prefs.dailyLimitMinutes = limit
                prefs.morningBlockMinutes = morning
                prefs.alarmEnabled = alarm
                onDone()
            }, modifier = Modifier.fillMaxWidth()) { Text("保存规则") }
            OutlinedButton(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("取消") }
        }
    }

    @Composable
    private fun StepSetting(label: String, value: String, minus: () -> Unit, plus: () -> Unit) {
        Card { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(label); Text(value, style = MaterialTheme.typography.titleLarge) }
            OutlinedButton(onClick = minus) { Text("−") }; Spacer(Modifier.width(8.dp)); OutlinedButton(onClick = plus) { Text("+") }
        } }
    }

    private fun isGuardEnabled(): Boolean {
        val expected = ComponentName(this, VideoGuardService::class.java).flattenToString()
        return Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.split(':')?.any { it.equals(expected, ignoreCase = true) } == true
    }

    private fun openAlarmPermission() {
        if (Build.VERSION.SDK_INT >= 31) startActivity(
            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
        )
    }

    private fun formatTime(time: Long): String = if (time <= 0) "待记录" else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))

    private fun feedbackText(prefs: AppPrefs, used: Int): String = when {
        prefs.blockedAttemptsToday >= 5 -> "今天已经被拦截${prefs.blockedAttemptsToday}次。冲动很强，先离开手机十分钟。"
        used > prefs.dailyLimitMinutes -> "今天已超出预算，视频号会继续保持封锁。"
        used >= prefs.dailyLimitMinutes * 0.8 -> "额度快用完了，把剩下的注意力留给晚上。"
        else -> "目前仍在计划内。守住早晨，今天就成功了一半。"
    }
}
