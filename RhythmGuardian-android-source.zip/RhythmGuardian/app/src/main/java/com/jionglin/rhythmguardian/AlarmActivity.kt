package com.jionglin.rhythmguardian

import android.app.NotificationManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class AlarmActivity : ComponentActivity() {
    private var ringtone: Ringtone? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)).apply {
            if (android.os.Build.VERSION.SDK_INT >= 28) isLooping = true
            play()
        }
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.primaryContainer) {
                    Column(
                        Modifier.padding(28.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val prefs = AppPrefs(this@AlarmActivity)
                        Text("%02d:%02d".format(prefs.wakeHour, prefs.wakeMinute), style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
                        Text("起床，先把今天拿回来")
                        Spacer(Modifier.height(32.dp))
                        Button(onClick = ::confirmAwake, modifier = Modifier.fillMaxWidth()) { Text("我已起床") }
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = ::snooze, modifier = Modifier.fillMaxWidth()) { Text("再睡 5 分钟（扣 10 分）") }
                    }
                }
            }
        }
    }

    private fun confirmAwake() {
        val now = System.currentTimeMillis()
        val prefs = AppPrefs(this)
        prefs.lastWakeAt = now
        val estimate = UsageRepository(this).estimateLastUseBeforeWake(now)
        if (estimate > 0) prefs.lastEstimatedBedtime = estimate
        EventStore(this).add("WAKE", "按时确认起床，奖励20分", 20)
        AlarmScheduler.scheduleMorningReview(this, now)
        stopAndClose()
    }

    private fun snooze() {
        EventStore(this).add("SNOOZE", "使用一次贪睡，扣10分", -10)
        val manager = getSystemService(android.app.AlarmManager::class.java)
        val pending = android.app.PendingIntent.getBroadcast(
            this, 800, android.content.Intent(this, AlarmReceiver::class.java),
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        manager.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 5 * 60_000L, pending)
        stopAndClose()
    }

    private fun stopAndClose() {
        ringtone?.stop()
        getSystemService(NotificationManager::class.java).cancel(801)
        finishAndRemoveTask()
    }

    override fun onDestroy() { ringtone?.stop(); super.onDestroy() }
}
