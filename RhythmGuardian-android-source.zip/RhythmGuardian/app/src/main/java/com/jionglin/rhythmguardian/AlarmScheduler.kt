package com.jionglin.rhythmguardian

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.LocalDateTime
import java.time.ZoneId

object AlarmScheduler {
    const val CHANNEL_ID = "wake_alarm"
    private const val REQUEST_CODE = 800

    fun schedule(context: Context) {
        val prefs = AppPrefs(context)
        val manager = context.getSystemService(AlarmManager::class.java)
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_CODE, Intent(context, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        manager.cancel(pending)
        scheduleDailyReview(context)
        if (!prefs.alarmEnabled) return

        var next = LocalDateTime.now().withHour(prefs.wakeHour).withMinute(prefs.wakeMinute)
            .withSecond(0).withNano(0)
        if (!next.isAfter(LocalDateTime.now())) next = next.plusDays(1)
        val at = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || manager.canScheduleExactAlarms()) {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        } else {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        }
    }

    fun scheduleMorningReview(context: Context, wakeAt: Long) {
        val delay = AppPrefs(context).morningBlockMinutes * 60_000L
        val pending = PendingIntent.getBroadcast(
            context, 802, Intent(context, MorningReviewReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, wakeAt + delay, pending)
    }

    fun scheduleDailyReview(context: Context) {
        var next = LocalDateTime.now().withHour(23).withMinute(50).withSecond(0).withNano(0)
        if (!next.isAfter(LocalDateTime.now())) next = next.plusDays(1)
        val pending = PendingIntent.getBroadcast(
            context, 803, Intent(context, DailyReviewReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),
            pending
        )
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val notifications = context.getSystemService(NotificationManager::class.java)
        notifications.createNotificationChannel(
            NotificationChannel(AlarmScheduler.CHANNEL_ID, "起床闹钟", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "每天的强制起床提醒"
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
        )
        val fullScreen = PendingIntent.getActivity(
            context, 801, Intent(context, AlarmActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, AlarmScheduler.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("该起床了")
            .setContentText("关闭闹钟后，视频号将封锁90分钟。")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(fullScreen, true)
            .build()
        notifications.notify(801, notification)
        EventStore(context).add("ALARM", "起床闹钟响起")
        AlarmScheduler.schedule(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) = AlarmScheduler.schedule(context)
}

class MorningReviewReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = AppPrefs(context)
        val success = prefs.lastWakeAt > 0 && !EventStore(context).hasEventSince("BLOCK", prefs.lastWakeAt)
        val detail = if (success) "守住晨间90分钟，奖励30分" else "晨间保护期出现刷视频尝试，今天继续加油"
        EventStore(context).add("MORNING_REVIEW", detail, if (success) 30 else 0)
        reviewNotification(context, "晨间结算", detail, 804)
    }
}

class DailyReviewReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = AppPrefs(context)
        val today = java.time.LocalDate.now().toString()
        if (prefs.rewardedDay != today) {
            val used = (UsageRepository(context).weChatUsageTodayMillis() / 60_000L).toInt()
            val (detail, delta) = when {
                used <= prefs.dailyLimitMinutes -> "今日控制在${used}分钟，奖励40分" to 40
                used > prefs.dailyLimitMinutes * 2 -> "今日使用${used}分钟，超过双倍额度，扣20分" to -20
                else -> "今日使用${used}分钟，超过目标但没有失控" to 0
            }
            EventStore(context).add("DAILY_REVIEW", detail, delta)
            prefs.rewardedDay = today
            reviewNotification(context, "今日作息反馈", detail, 805)
        }
        AlarmScheduler.scheduleDailyReview(context)
    }
}

private fun reviewNotification(context: Context, title: String, detail: String, id: Int) {
    val manager = context.getSystemService(NotificationManager::class.java)
    val channel = "rhythm_feedback"
    manager.createNotificationChannel(NotificationChannel(channel, "作息反馈", NotificationManager.IMPORTANCE_DEFAULT))
    val open = PendingIntent.getActivity(
        context, id, Intent(context, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    manager.notify(id, NotificationCompat.Builder(context, channel)
        .setSmallIcon(android.R.drawable.ic_popup_reminder)
        .setContentTitle(title).setContentText(detail).setContentIntent(open).setAutoCancel(true).build())
}
