package com.jionglin.rhythmguardian

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Process
import android.provider.Settings
import java.time.LocalDate
import java.time.ZoneId

class UsageRepository(private val context: Context) {
    private val manager = context.getSystemService(UsageStatsManager::class.java)

    fun hasUsageAccess(): Boolean {
        val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun weChatUsageTodayMillis(): Long {
        if (!hasUsageAccess()) return 0L
        val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        return manager.queryAndAggregateUsageStats(start, System.currentTimeMillis())[WECHAT_PACKAGE]
            ?.totalTimeInForeground ?: 0L
    }

    fun estimateLastUseBeforeWake(wakeAt: Long): Long {
        if (!hasUsageAccess()) return 0L
        val start = wakeAt - 16 * 60 * 60 * 1000L
        val cutoff = wakeAt - 90 * 60 * 1000L
        val events = manager.queryEvents(start, cutoff)
        val event = UsageEvents.Event()
        var last = 0L
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                event.eventType == UsageEvents.Event.ACTIVITY_PAUSED ||
                event.eventType == UsageEvents.Event.SCREEN_NON_INTERACTIVE
            ) last = maxOf(last, event.timeStamp)
        }
        return last
    }

    companion object {
        const val WECHAT_PACKAGE = "com.tencent.mm"
        val usageSettingsIntent get() = android.content.Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
    }
}
