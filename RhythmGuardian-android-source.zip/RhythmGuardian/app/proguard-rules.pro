# Version 0.1 keeps release builds unobfuscated to simplify personal testing.
